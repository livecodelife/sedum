import {{path|quote}}

